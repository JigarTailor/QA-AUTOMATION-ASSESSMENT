package ABSA;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;
import com.google.common.io.Files;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class ABSATest {

      public WebDriver d;
      public ExtentReports Report = new ExtentReports(System.getProperty("user.dir")+"//ExtentReportResults.html", true);
      public ExtentTest test;
      public WebDriverWait W;
      public Date date = new Date(System.currentTimeMillis());
      public SimpleDateFormat dateFormat = new SimpleDateFormat("yymmss");
      public Robot R;

  @Test(priority=1)
  public void OpenURL() {
        test = Report.startTest("Open URL", "Crome browser opens URL");
        System.setProperty("webdriver.chrome.driver", "C:\\chromedriver_win32\\chromedriver.exe");
        d = new ChromeDriver();
        d.manage().window().maximize();
        d.get("http://www.way2automation.com/angularjs-protractor/webtables/");
        test.log(LogStatus.INFO, "Open URL", "Crome browser opens URL");
        CaptureScreenShot(d, "01_Open URL");
        test.log(LogStatus.INFO, test.addScreenCapture("01_Open URL.png"));
        System.out.println("Crome browser opens URL");
  }
  @Test(priority=2)
  public void ValidateUserListPage() {
        test = Report.startTest("Validate User List Page", "Are we on User List Page..??");
            if("Add User".equals(d.findElement(By.xpath("//button[@type='add']")).getText())){
              System.out.println("We are on USER LIST PAGE");
              test.log(LogStatus.INFO, "Validate User List Page", "We are on User List Page");
              CaptureScreenShot(d, "02_Validate User List Page");
              test.log(LogStatus.INFO, test.addScreenCapture("02_Validate User List Page.png"));
              System.out.println("Validate User List Page");
            }
  }
  @Test(priority=3)
  public void ClickOnADDUSER() {
        test = Report.startTest("Click on Add User", "Click on ADD USER");
        d.findElement(By.xpath("//button[@type='add']")).click();
        test.log(LogStatus.INFO, "Click on Add User", "Click on ADD USER");
        CaptureScreenShot(d, "03_Add User");
        test.log(LogStatus.INFO, test.addScreenCapture("03_Add User.png"));
        System.out.println("Click on Add User");
  }
  @Test(priority=4)
  public void AddUSER1() throws InterruptedException {
        test = Report.startTest("Add User1", "Adding the First User information");
        d.findElement(By.xpath("//input[@name='FirstName']")).sendKeys("FName1");
        d.findElement(By.xpath("//input[@name='LastName']")).sendKeys("LName1");
        d.findElement(By.xpath("//input[@name='UserName']")).sendKeys("User" + dateFormat.format(date));
        d.findElement(By.xpath("//input[@name='Password']")).sendKeys("Pass1");
        Thread.sleep(2000);
        d.findElement(By.xpath("//input[@value='15']")).click();
        Thread.sleep(2000);
        Select Role = new Select(d.findElement(By.xpath("//select[@name='RoleId']")));
        Role.selectByValue("2");
        d.findElement(By.xpath("//input[@name='Email']")).sendKeys("admin@mail.com");
        d.findElement(By.xpath("//input[@name='Mobilephone']")).sendKeys("082555");
        test.log(LogStatus.INFO, "Add User1", "Adding the First User information");
        CaptureScreenShot(d, "04_Add User1");
        test.log(LogStatus.INFO, test.addScreenCapture("04_Add User1.png"));
        System.out.println("Adding first USER information");
        Thread.sleep(2000);
        d.findElement(By.xpath("//button[@class='btn btn-success']")).click();
        Thread.sleep(2000);
        CaptureScreenShot(d, "05_After Adding User1");
        test.log(LogStatus.INFO, test.addScreenCapture("05_After Adding User1.png"));
        System.out.println("Added first USER information");
  }
  @Test(priority=5)
  public void AddUSER2() throws InterruptedException, AWTException {
        test = Report.startTest("Add User2", "Adding the Second User information");
        d.findElement(By.xpath("//button[@type='add']")).click();
        			R  = new Robot();
        WebElement 	W1 = d.findElement(By.xpath("//input[@name='FirstName']"));
        			W1.click();
        			R.keyPress(KeyEvent.VK_CONTROL);
        			R.keyPress(KeyEvent.VK_A);
        			R.keyRelease(KeyEvent.VK_CONTROL);
        			W1.sendKeys("FName2");
        WebElement 	W2 = d.findElement(By.xpath("//input[@name='LastName']"));
        			W2.click();
					R.keyPress(KeyEvent.VK_CONTROL);
					R.keyPress(KeyEvent.VK_A);
					R.keyRelease(KeyEvent.VK_CONTROL);
					W2.sendKeys("LName2");
		WebElement 	W3 = d.findElement(By.xpath("//input[@name='UserName']"));
					W3.click();
					R.keyPress(KeyEvent.VK_CONTROL);
					R.keyPress(KeyEvent.VK_A);
					R.keyRelease(KeyEvent.VK_CONTROL);
					W3.sendKeys("User" + dateFormat.format(date));
		WebElement 	W4 = d.findElement(By.xpath("//input[@name='Password']"));
					W4.click();
					R.keyPress(KeyEvent.VK_CONTROL);
					R.keyPress(KeyEvent.VK_A);
					R.keyRelease(KeyEvent.VK_CONTROL);
					W4.sendKeys("Pass2");
        Thread.sleep(2000);
        d.findElement(By.xpath("//input[@value='16']")).click();
        Thread.sleep(2000);
        Select Role = new Select(d.findElement(By.xpath("//select[@name='RoleId']")));
        Role.selectByValue("1");
		WebElement 	W5 = d.findElement(By.xpath("//input[@name='Email']"));
					W5.click();
					R.keyPress(KeyEvent.VK_CONTROL);
					R.keyPress(KeyEvent.VK_A);
					R.keyRelease(KeyEvent.VK_CONTROL);
					W5.sendKeys("customer@mail.com");
		WebElement 	W6 = d.findElement(By.xpath("//input[@name='Mobilephone']"));
					W6.click();
					R.keyPress(KeyEvent.VK_CONTROL);
					R.keyPress(KeyEvent.VK_A);
					R.keyRelease(KeyEvent.VK_CONTROL);
					W6.sendKeys("083444");
        test.log(LogStatus.INFO, "Add User2", "Adding the Second User information");
        CaptureScreenShot(d, "06_Add User2");
        test.log(LogStatus.INFO, test.addScreenCapture("06_Add User2.png"));
        System.out.println("Adding second USER information");
        Thread.sleep(2000);
        d.findElement(By.xpath("//button[@class='btn btn-success']")).click();
        Thread.sleep(2000);
        CaptureScreenShot(d, "07_After Adding User2");
        test.log(LogStatus.INFO, test.addScreenCapture("07_After Adding User2.png"));
        System.out.println("Added second USER information");
  }
  @Test(priority=6)
  public void Confirmation(){
      test = Report.startTest("Confirmation", "Confirmation of Users being added");
	  Assert.assertEquals("FName2", d.findElement(By.xpath("//html//body//table//tbody//tr[1]//td[1]")).getText());
	  System.out.println("Second record: "+d.findElement(By.xpath("//html//body//table//tbody//tr[1]//td[1]")).getText());
	  Assert.assertEquals("FName1", d.findElement(By.xpath("//html//body//table//tbody//tr[2]//td[1]")).getText());
	  System.out.println("First record: "+d.findElement(By.xpath("//html//body//table//tbody//tr[2]//td[1]")).getText());
      test.log(LogStatus.INFO, "Confirmation", "Confirmation of Users being added");
      test.log(LogStatus.INFO, test.addScreenCapture("07_After Adding User2.png"));
  }
  @AfterTest
  public void END(){
      Report.endTest(test);
      Report.flush();
      d.get("C:\\Users\\J H Tailor\\eclipse-workspace\\ABSA\\ExtentReportResults.html");
        System.out.println("Please view the Report");
  }
  public static String CaptureScreenShot(WebDriver driver, String ScreenshotName) {
      try {
          TakesScreenshot Scrns = (TakesScreenshot)driver;
          File Source = Scrns.getScreenshotAs(OutputType.FILE);
          Files.copy(Source,new File(ScreenshotName+".png"));
          //Files.copy(Source,new File("./ScreenShots/"+ScreenshotName+".png"));         
          System.out.println(ScreenshotName+"--->ScreenShot Taken");        
      } catch (Exception e) {
System.out.println("Error Message = "+e.getMessage());
      }
            return ScreenshotName;
  }
}